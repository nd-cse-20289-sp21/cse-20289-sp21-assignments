/* hammer.c: Hammer Functions */

#include "hammer.h"
#include "http.h"
#include "timestamp.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

/**
 * Make n HTTP requests to the specified url, while writing the contents of the
 * request to the specified stream.
 *
 * Each HTTP request must be performed by a separate child process.
 *
 * @param   url         Make HTTP requests to this URL.
 * @param   stream      Write the contents of each response to this stream.
 * @param   n           The number of HTTP requests to make.
 * @return  True if all children were successful.
 **/
bool	hammer(const URL *url, FILE *stream, size_t n) {
    /* TODO: Spawn children.
     * Each child must do the following:
     *  1. Make a HTTP request to given URL.
     *  2. Time the HTTP request.
     *  3. Print the bandwidth if any data was written to stderr.
     *  4. Exit with success if the HTTP request was successful.
     **/

    /* TODO: Wait for children. */

    /* TODO: Print elapsed time to stderr. */
    return false;
}

/* vim: set expandtab sts=4 sw=4 ts=8 ft=c: */
