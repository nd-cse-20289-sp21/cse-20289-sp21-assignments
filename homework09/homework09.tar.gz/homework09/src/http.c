/* http.c: HTTP Client Functions */

#include "http.h"
#include "macros.h"
#include "socket.h"
#include "url.h"

/** 
 * Make a HTTP request to specified URL and write the contents of the response
 * to the specified stream.
 *
 * @param   url     Make a HTTP request to this URL.
 * @param   stream  Write the contents of response to this stream.
 * @return  -1 on error, otherwise the number of bytes written.
 **/
ssize_t http_get(const URL *url, FILE *stream) {
    /* TODO: Connect to remote host and port */

    /* TODO: Send request to server */

    /* TODO: Read response status from server */

    /* TODO: Read response headers from server */

    /* TODO: Read response body from server */

    /* TODO: Close connection */

    /* TODO: Return number of bytes written and check if it matches Content-Length */
}

/* vim: set expandtab sts=4 sw=4 ts=8 ft=c: */
