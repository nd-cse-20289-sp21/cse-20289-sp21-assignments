/* socket.h */

#pragma once

#include <stdio.h>

/* Functions */

FILE *	socket_dial(const char *host, const char *port);

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
